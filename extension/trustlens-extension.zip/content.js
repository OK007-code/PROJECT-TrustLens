(() => {
  // client/src/data/trustlensData.js
  var BRANDS = [
    "hdfc",
    "sbi",
    "icici",
    "axis",
    "kotak",
    "paytm",
    "phonepe",
    "googlepay",
    "gpay",
    "amazon",
    "flipkart",
    "myntra",
    "meesho",
    "irctc",
    "india post",
    "indiapost",
    "fedex",
    "dhl",
    "bluedart",
    "swiggy",
    "zomato",
    "jio",
    "airtel",
    "vi",
    "lic",
    "uidai",
    "income tax",
    "passport seva",
    "netflix",
    "whatsapp"
  ];
  var SUSPICIOUS_TLDS = [".xyz", ".top", ".click", ".icu", ".vip", ".live", ".buzz", ".work", ".fit"];
  var URL_SHORTENERS = ["bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "shorturl.at"];
  var KEYWORDS = {
    urgency: ["24 hours", "24 hrs", "immediately", "urgent", "last chance", "act now", "aaj hi", "abhi", "turant", "jaldi", "today only", "expire today"],
    authorityFear: ["account blocked", "account will be blocked", "kyc expired", "kyc suspend", "police", "cbi", "customs", "arrest", "digital arrest", "court case", "legal action", "income tax", "cyber cell", "parcel seized"],
    moneyAsk: ["registration fee", "processing fee", "verification fee", "pay to receive", "gift card", "crypto", "deposit", "refundable fee", "upi collect", "send money", "pay rs", "pay \u20B9"],
    tooGood: ["70% off", "80% off", "90% off", "earn rs 5000/day", "earn \u20B95000/day", "work from home", "guaranteed returns", "double your money", "free iphone", "lucky winner", "congratulations you won", "cashback of rs"],
    credentials: ["otp", "one time password", "pin", "upi pin", "cvv", "card number", "aadhaar", "aadhar", "pan card", "bank details", "netbanking password", "login password"],
    tricks: ["enter your pin to receive", "receive money", "collect request", "task completion", "review and earn", "electricity will be disconnected", "bill overdue", "lottery", "prize", "job offer", "registration fee"]
  };

  // client/src/lib/rules/engine.js
  var clean = (value) => value.replace(/\s+/g, " ").trim();
  var lower = (value) => value.toLocaleLowerCase("en-IN");
  function findEvidence(input, terms) {
    const normalized = lower(input);
    for (const term of terms) {
      const index = normalized.indexOf(lower(term));
      if (index >= 0)
        return input.slice(index, index + term.length);
    }
    return void 0;
  }
  function addFinding(findings, id, category, tactic, evidence, severity, weight, explanation, explanation_hi) {
    if (!evidence || findings.some((finding) => finding.id === id))
      return;
    findings.push({ id, category, tactic, evidence: clean(evidence), severity, weight, explanation, explanation_hi });
  }
  function extractUrl(input) {
    const match = input.match(/(?:https?:\/\/)?(?:www\.)?[^\s]+\.[a-z]{2,}(?:\/[^\s]*)?/i);
    return match?.[0]?.replace(/[),.;]+$/, "") ?? (input.includes(".") ? input.trim() : "");
  }
  function analyzeUrl(input, findings) {
    const rawUrl = extractUrl(input);
    if (!rawUrl)
      return;
    const candidate = rawUrl.startsWith("http") ? rawUrl : `https://${rawUrl}`;
    let url;
    try {
      url = new URL(candidate);
    } catch {
    }
    const hostname = lower(url?.hostname ?? rawUrl.split("/")[0]);
    const full = lower(rawUrl);
    if (hostname.includes("xn--") || full.includes("%")) {
      addFinding(findings, "punycode", "scam", "Punycode / encoded domain", rawUrl, "high", 20, "This address uses an encoded domain that can visually imitate a trusted website.", "\u092F\u0939 \u092A\u0924\u093E encoded domain \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0915\u0930\u0924\u093E \u0939\u0948 \u091C\u094B \u092D\u0930\u094B\u0938\u0947\u092E\u0902\u0926 \u0935\u0947\u092C\u0938\u093E\u0907\u091F \u091C\u0948\u0938\u093E \u0926\u093F\u0916 \u0938\u0915\u0924\u093E \u0939\u0948\u0964");
    }
    if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname)) {
      addFinding(findings, "ip-url", "scam", "IP address link", hostname, "high", 24, "Real customer-service sites normally use a recognisable domain, not a bare IP address.", "\u0905\u0938\u0932\u0940 customer-service \u0935\u0947\u092C\u0938\u093E\u0907\u091F \u0906\u092E \u0924\u094C\u0930 \u092A\u0930 IP address \u0915\u0947 \u092C\u091C\u093E\u092F \u092A\u0939\u091A\u093E\u0928\u0947 \u091C\u093E\u0928\u0947 \u0935\u093E\u0932\u093E domain \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0915\u0930\u0924\u0940 \u0939\u0948\u0964");
    }
    if (!url || url.protocol !== "https:") {
      addFinding(findings, "no-https", "scam", "No secure connection", rawUrl, "medium", 12, "The link does not clearly use a secure HTTPS connection.", "\u092F\u0939 \u0932\u093F\u0902\u0915 \u0938\u0941\u0930\u0915\u094D\u0937\u093F\u0924 HTTPS connection \u0915\u093E \u0909\u092A\u092F\u094B\u0917 \u0928\u0939\u0940\u0902 \u0915\u0930 \u0930\u0939\u093E \u0939\u0948\u0964");
    }
    const hyphens = (hostname.match(/-/g) ?? []).length;
    const subdomains = hostname.split(".").length - 2;
    if (hyphens >= 2 || subdomains >= 3) {
      addFinding(findings, "weird-host", "scam", "Unusual domain structure", hostname, "medium", 16, "Extra hyphens or subdomains can be used to make an impersonation link look official.", "\u0905\u0924\u093F\u0930\u093F\u0915\u094D\u0924 hyphens \u092F\u093E subdomains impersonation link \u0915\u094B official \u091C\u0948\u0938\u093E \u0926\u093F\u0916\u093E\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0939\u094B \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964");
    }
    const tld = hostname.match(/\.[a-z]{2,}$/)?.[0] ?? "";
    if (SUSPICIOUS_TLDS.includes(tld)) {
      addFinding(findings, "suspicious-tld", "scam", "Suspicious domain ending", tld, "medium", 18, "This domain ending is common in disposable or low-trust sites. The ending alone is not proof, but it raises the risk.", "\u092F\u0939 domain ending \u0905\u0938\u094D\u0925\u093E\u092F\u0940 \u092F\u093E \u0915\u092E-\u092D\u0930\u094B\u0938\u0947 \u0935\u093E\u0932\u0940 sites \u092E\u0947\u0902 \u0906\u092E \u0939\u0948\u0964 \u0905\u0915\u0947\u0932\u0947 \u0907\u0938\u0938\u0947 scam \u0938\u093E\u092C\u093F\u0924 \u0928\u0939\u0940\u0902 \u0939\u094B\u0924\u093E, \u0932\u0947\u0915\u093F\u0928 risk \u092C\u0922\u093C\u0924\u093E \u0939\u0948\u0964");
    }
    const shortener = URL_SHORTENERS.find((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
    if (shortener) {
      addFinding(findings, "shortener", "scam", "Shortened URL", shortener, "medium", 14, "A shortened link hides the destination, so verify it before opening or paying.", "Shortened link destination \u091B\u0941\u092A\u093E\u0924\u093E \u0939\u0948, \u0907\u0938\u0932\u093F\u090F \u0907\u0938\u0947 \u0916\u094B\u0932\u0928\u0947 \u092F\u093E payment \u0938\u0947 \u092A\u0939\u0932\u0947 verify \u0915\u0930\u0947\u0902\u0964");
    }
    for (const brand of BRANDS) {
      const compact = brand.replace(/\s/g, "");
      if (!hostname.includes(compact))
        continue;
      const officialish = hostname === `${compact}.com` || hostname.endsWith(`.${compact}.com`) || hostname.endsWith(`.${compact}.in`);
      const strange = !officialish && (hostname.includes("-") || !hostname.endsWith(".com") && !hostname.endsWith(".in"));
      if (strange) {
        addFinding(findings, `brand-${compact}`, "scam", "Lookalike brand domain", hostname, "critical", 32, `The address uses \u201C${brand}\u201D in a domain that does not look like the brand\u2019s official website.`, `\u0907\u0938 address \u092E\u0947\u0902 \u201C${brand}\u201D \u0915\u093E \u0928\u093E\u092E \u0939\u0948, \u0932\u0947\u0915\u093F\u0928 domain \u0909\u0938 brand \u0915\u0940 official website \u091C\u0948\u0938\u093E \u0928\u0939\u0940\u0902 \u0926\u093F\u0916\u0924\u093E\u0964`);
        break;
      }
    }
  }
  function analyzeText(input, findings) {
    const urgency = findEvidence(input, KEYWORDS.urgency);
    const authority = findEvidence(input, KEYWORDS.authorityFear);
    const money = findEvidence(input, KEYWORDS.moneyAsk);
    const tooGood = findEvidence(input, KEYWORDS.tooGood);
    const credentials = findEvidence(input, KEYWORDS.credentials);
    const tricks = findEvidence(input, KEYWORDS.tricks);
    addFinding(findings, "urgency", "dark_pattern", "Urgency pressure", urgency ?? "", "medium", 13, "Urgent wording rushes you so you have less time to verify the request.", "\u091C\u0932\u094D\u0926\u0940 \u0915\u0930\u0928\u0947 \u0935\u093E\u0932\u093E wording \u0906\u092A\u0915\u094B verify \u0915\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F \u0915\u092E \u0938\u092E\u092F \u0926\u0947\u0924\u093E \u0939\u0948\u0964");
    addFinding(findings, "authority", "scam", "Authority + fear", authority ?? "", "high", 22, "The sender uses fear or authority to make you obey before thinking.", "\u092D\u0947\u091C\u0928\u0947 \u0935\u093E\u0932\u093E \u0921\u0930 \u092F\u093E authority \u0915\u093E \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0915\u0930\u0915\u0947 \u0906\u092A\u0915\u094B \u0938\u094B\u091A\u0928\u0947 \u0938\u0947 \u092A\u0939\u0932\u0947 \u092E\u093E\u0928\u0928\u0947 \u092A\u0930 \u092E\u091C\u092C\u0942\u0930 \u0915\u0930\u0924\u093E \u0939\u0948\u0964");
    addFinding(findings, "money", "scam", "Unexpected money request", money ?? "", "high", 24, "Upfront fees, gift cards, crypto, or collect requests are common scam payment paths.", "\u092A\u0939\u0932\u0947 \u092A\u0948\u0938\u0947, gift cards, crypto \u092F\u093E collect request scam \u092E\u0947\u0902 \u0906\u092E payment \u0930\u093E\u0938\u094D\u0924\u0947 \u0939\u0948\u0902\u0964");
    addFinding(findings, "too-good", "scam", "Too-good-to-be-true promise", tooGood ?? "", "high", 20, "Guaranteed profit or unusually large rewards are a classic lure. Real opportunities explain risk and conditions.", "Guaranteed profit \u092F\u093E \u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E reward \u0905\u0915\u094D\u0938\u0930 \u0932\u093E\u0932\u091A \u0915\u093E \u091C\u093E\u0932 \u0939\u094B\u0924\u093E \u0939\u0948\u0964 \u0905\u0938\u0932\u0940 \u0905\u0935\u0938\u0930 risk \u0914\u0930 conditions \u0938\u092E\u091D\u093E\u0924\u0947 \u0939\u0948\u0902\u0964");
    addFinding(findings, "credentials", "scam", "Sensitive detail request", credentials ?? "", "critical", 30, "Never share OTP, PIN, CVV, Aadhaar, PAN, or passwords to receive money or fix an account.", "\u092A\u0948\u0938\u0947 \u092A\u093E\u0928\u0947 \u092F\u093E account \u0920\u0940\u0915 \u0915\u0930\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F OTP, PIN, CVV, Aadhaar, PAN \u092F\u093E password \u0915\u092D\u0940 share \u0928 \u0915\u0930\u0947\u0902\u0964");
    addFinding(findings, "trick", "scam", "Known scam script", tricks ?? "", "high", 22, "This phrase matches a script often used in task, courier, electricity, lottery, or UPI scams.", "\u092F\u0939 phrase task, courier, electricity, lottery \u092F\u093E UPI scam \u092E\u0947\u0902 \u0905\u0915\u094D\u0938\u0930 \u0907\u0938\u094D\u0924\u0947\u092E\u093E\u0932 \u0939\u094B\u0928\u0947 \u0935\u093E\u0932\u0940 script \u0938\u0947 \u092E\u093F\u0932\u0924\u093E \u0939\u0948\u0964");
  }
  function analyzeDarkPatterns(input, findings) {
    const patterns = [
      ["countdown", ["ends in", "offer ends", "timer", "minutes left", "seconds left"], "Fake countdown", "high", 18, "A countdown can manufacture pressure even when the offer may not really expire.", "Countdown \u0910\u0938\u093E pressure \u092C\u0928\u093E \u0938\u0915\u0924\u093E \u0939\u0948 \u091C\u094B \u0905\u0938\u0932\u0940 expiry \u0928 \u0939\u094B\u0928\u0947 \u092A\u0930 \u092D\u0940 \u0906\u092A\u0915\u094B \u091C\u0932\u094D\u0926\u0940 \u0915\u0930\u093E\u090F\u0964"],
      ["scarcity", ["only 2 left", "only 1 left", "people are viewing", "left in stock", "limited stock"], "Fake scarcity", "medium", 13, "Scarcity claims can push you to buy before comparing or checking the seller.", "Scarcity claims \u0906\u092A\u0915\u094B seller check \u092F\u093E comparison \u0915\u093F\u090F \u092C\u093F\u0928\u093E \u0916\u0930\u0940\u0926\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F push \u0915\u0930 \u0938\u0915\u0924\u0947 \u0939\u0948\u0902\u0964"],
      ["confirmshaming", ["no, i don't want to save money", "no thanks, i hate saving", "i don't want"], "Confirmshaming", "medium", 12, "The page frames a normal refusal as foolish or wasteful to wear down your choice.", "Page \u0938\u093E\u092E\u093E\u0928\u094D\u092F \u092E\u0928\u093E \u0915\u0930\u0928\u0947 \u0915\u094B \u092E\u0942\u0930\u094D\u0916\u0924\u093E \u091C\u0948\u0938\u093E \u0926\u093F\u0916\u093E\u0915\u0930 \u0906\u092A\u0915\u093E decision \u092C\u0926\u0932\u0928\u0947 \u0915\u0940 \u0915\u094B\u0936\u093F\u0936 \u0915\u0930\u0924\u093E \u0939\u0948\u0964"],
      ["preticked", ["selected", "pre-selected", "add protection", "insurance", "secure delivery"], "Pre-ticked add-on", "medium", 14, "An extra product or fee should never be added by default without your clear choice.", "\u0915\u094B\u0908 extra product \u092F\u093E fee \u0906\u092A\u0915\u0940 \u0938\u093E\u092B\u093C choice \u0915\u0947 \u092C\u093F\u0928\u093E default \u092E\u0947\u0902 add \u0928\u0939\u0940\u0902 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F\u0964"],
      ["drip-pricing", ["platform fee", "handling fee", "convenience fee", "extra fee", "+ \u20B9", "final price"], "Drip pricing", "high", 18, "Fees revealed late make the true price harder to compare.", "\u092C\u093E\u0926 \u092E\u0947\u0902 \u0926\u093F\u0916\u0928\u0947 \u0935\u093E\u0932\u0940 fees \u0905\u0938\u0932\u0940 price \u0915\u094B compare \u0915\u0930\u0928\u093E \u092E\u0941\u0936\u094D\u0915\u093F\u0932 \u092C\u0928\u093E\u0924\u0940 \u0939\u0948\u0902\u0964"],
      ["cancel", ["tiny", "unsubscribe", "cancel subscription", "hidden", "grey text"], "Hidden cancellation", "medium", 15, "A tiny or hidden cancel path makes it harder to leave than to sign up.", "\u091B\u094B\u091F\u093E \u092F\u093E \u091B\u0941\u092A\u093E cancel \u0930\u093E\u0938\u094D\u0924\u093E sign up \u0915\u094B \u0906\u0938\u093E\u0928 \u0914\u0930 \u091B\u094B\u0921\u093C\u0928\u093E \u092E\u0941\u0936\u094D\u0915\u093F\u0932 \u092C\u0928\u093E\u0924\u093E \u0939\u0948\u0964"]
    ];
    const normalized = lower(input);
    for (const [id, terms, tactic, severity, weight, explanation, explanation_hi] of patterns) {
      const evidence = findEvidence(input, terms);
      if (evidence || id === "preticked" && /selected|insurance/i.test(normalized)) {
        addFinding(findings, id, "dark_pattern", tactic, evidence ?? "selected", severity, weight, explanation, explanation_hi);
      }
    }
  }
  function verdictFor(manipulationScore, fraudScore) {
    if (fraudScore >= 72 || manipulationScore >= 82)
      return "scam";
    if (fraudScore >= 45 || manipulationScore >= 58)
      return "deceptive";
    if (manipulationScore >= 25 || fraudScore >= 20)
      return "pushy";
    return "safe";
  }
  function adviceFor(verdict, findings) {
    const advice = [
      "Pause. Do not click, pay, or share personal details while you verify.",
      "Open the official app or type the organisation\u2019s website yourself instead of using this link.",
      "If money or credentials were shared, contact your bank immediately and report at 1930 (India\u2019s cyber-fraud helpline)."
    ];
    if (verdict === "safe")
      return ["No strong manipulation signals were found. Still verify unexpected requests through an official channel.", "Keep software and browser warnings enabled."];
    if (findings.some((finding) => finding.id === "credentials"))
      advice.unshift("Never share OTP, UPI PIN, CVV, Aadhaar, PAN, or passwords. Banks and payment apps do not ask for them over calls or messages.");
    if (findings.some((finding) => finding.id === "money"))
      advice.unshift("Do not pay a registration, processing, verification, or release fee to receive money, a job, a parcel, or a prize.");
    return advice.slice(0, 4);
  }
  function analyzeInput(input, kind = "message") {
    const safeInput = clean(input).slice(0, 5e3);
    const findings = [];
    if (kind === "link" || /https?:\/\/|\b[a-z0-9-]+\.(?:com|in|org|xyz|top|click|icu)\b/i.test(safeInput))
      analyzeUrl(safeInput, findings);
    analyzeText(safeInput, findings);
    if (kind === "page" || findings.some((finding) => finding.category === "dark_pattern"))
      analyzeDarkPatterns(safeInput, findings);
    const manipulationScore = Math.min(100, Math.round(findings.filter((finding) => finding.category === "dark_pattern").reduce((total, finding) => total + finding.weight, 0) * 1.8));
    const fraudScore = Math.min(100, Math.round(findings.filter((finding) => finding.category === "scam").reduce((total, finding) => total + finding.weight, 0) * 1.55));
    const verdict = verdictFor(manipulationScore, fraudScore);
    return { manipulationScore, fraudScore, verdict, reasons: findings, advice: adviceFor(verdict, findings), input: safeInput, kind, source: "rules", analyzedAt: (/* @__PURE__ */ new Date()).toISOString() };
  }

  // extension/src/content.js
  var active = false;
  var marks = [];
  var badge = null;
  function clearShield() {
    marks.forEach(({ element, outline, title }) => {
      element.style.outline = outline;
      if (title === null) element.removeAttribute("title");
      else element.title = title;
    });
    marks = [];
    badge?.remove();
    badge = null;
  }
  function addBadge(analysis) {
    badge = document.createElement("div");
    badge.id = "trustlens-extension-badge";
    badge.textContent = `TrustLens \xB7 ${Math.max(analysis.manipulationScore, analysis.fraudScore)}/100`;
    Object.assign(badge.style, {
      position: "fixed",
      zIndex: "2147483647",
      right: "18px",
      top: "18px",
      padding: "10px 13px",
      border: "1px solid #a7dcd5",
      borderRadius: "9px",
      color: "#08766f",
      background: "#f2fffc",
      boxShadow: "0 9px 22px rgba(10,99,92,.18)",
      font: "700 12px Arial,sans-serif",
      cursor: "pointer"
    });
    badge.title = "Turn off TrustLens Shield";
    badge.addEventListener("click", () => {
      active = false;
      clearShield();
    });
    document.documentElement.appendChild(badge);
  }
  function candidateElements() {
    return [...document.querySelectorAll("h1,h2,h3,p,a,button,label,input,form,[role=button]")].filter((element) => {
      const text = (element.innerText || element.getAttribute("aria-label") || element.getAttribute("placeholder") || "").trim();
      const rect = element.getBoundingClientRect();
      return text.length > 5 && rect.width > 0 && rect.height > 0;
    }).slice(0, 180);
  }
  function applyShield(analysis) {
    clearShield();
    active = true;
    const seen = /* @__PURE__ */ new Set();
    for (const element of candidateElements()) {
      const text = (element.innerText || element.getAttribute("aria-label") || element.getAttribute("placeholder") || "").trim().slice(0, 500);
      const local = analyzeInput(text, "page");
      const reason = local.reasons[0];
      if (!reason || seen.has(reason.id)) continue;
      seen.add(reason.id);
      const outline = element.style.outline;
      const title = element.getAttribute("title");
      element.style.outline = `3px solid ${reason.severity === "high" || reason.severity === "critical" ? "#df5a50" : "#f1a735"}`;
      element.title = `TrustLens: ${reason.tactic} \u2014 ${reason.explanation}`;
      marks.push({ element, outline, title });
      if (marks.length >= 8) break;
    }
    addBadge(analysis);
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "TRUSTLENS_SCAN_PAGE") {
      const pageText = (document.body?.innerText || document.title || "").slice(0, 5e3);
      const analysis = analyzeInput(`${location.href}
${pageText}`, "page");
      applyShield(analysis);
      sendResponse({ analysis, url: location.href });
      return true;
    }
    if (message.type === "TRUSTLENS_TOGGLE_SHIELD") {
      active = Boolean(message.enabled);
      if (active) {
        const pageText = (document.body?.innerText || document.title || "").slice(0, 5e3);
        applyShield(analyzeInput(`${location.href}
${pageText}`, "page"));
      } else clearShield();
      sendResponse({ enabled: active });
      return true;
    }
  });
})();
