(() => {
  // extension/src/background.js
  chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ trustlensInstalledAt: Date.now(), shieldEnabled: true });
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === "loading") {
      chrome.tabs.sendMessage(tabId, { type: "TRUSTLENS_PAGE_LOADING" }).catch(() => {
      });
    }
  });
})();
